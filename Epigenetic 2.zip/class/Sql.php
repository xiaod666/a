<?php
// class/Sql.php

class Sql
{
    private $connections = [];

    public function __construct()
    {
        // 加载数据库配置
        $config = include __DIR__ . '/../data/config.php';
        $sqlConfig = include __DIR__ . '/../data/sql.php';

        if ($config['Sql'] === 'sql') {
            // 单数据库模式
            if (!isset($sqlConfig['sql'])) {
                throw new Exception("Single database configuration not found.");
            }
            $this->connections['default'] = $this->connect($sqlConfig['sql']);
        } elseif ($config['Sql'] === 'sqls') {
            // 多数据库模式
            foreach ($sqlConfig['sqls'] as $key => $dbConfig) {
                $this->connections[$key] = $this->connect($dbConfig);
            }
        }
    }

    private function connect($config)
    {
        try {
            $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset={$config['charset']}";
            return new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    /**
     * 查询数据（支持单条或批量）
     *
     * @param string $table 表名
     * @param array|string $conditions 条件（字符串或数组）
     * @param string $fields 查询的字段，默认为 '*'
     * @param string $order 排序规则，默认为空
     * @param string|int|null $limit 限制查询结果数量，默认为空
     * @param string $connection 数据库连接名称
     * @return array 查询结果
     */
    public function row(
        $table,
        $conditions,
        $fields = '*',
        $order = '',
        $limit = null,
        $connection = 'default'
    ) {
        if (!isset($this->connections[$connection])) {
            throw new Exception("Connection '{$connection}' not found.");
        }

        $where = '';
        $params = [];

        // 构建 WHERE 子句
        if (is_array($conditions)) {
            $whereClauses = [];
            foreach ($conditions as $key => $value) {
                $whereClauses[] = "{$key} = ?";
                $params[] = $value;
            }
            $where = !empty($whereClauses) ? "WHERE " . implode(' AND ', $whereClauses) : '';
        } elseif (is_string($conditions) && !empty($conditions)) {
            // 直接使用字符串形式的条件（不推荐）
            $where = "WHERE {$conditions}";
        }

        // 构建 ORDER BY 子句
        $orderBy = !empty($order) ? "ORDER BY {$order}" : '';

        // 构建 LIMIT 子句
        $limitClause = '';
        if (!empty($limit)) {
            // 去除多余的 "LIMIT" 关键字
            $limit = trim(str_ireplace('LIMIT', '', $limit));
            // 验证 $limit 是否为合法值
            if (is_numeric($limit) || preg_match('/^\d+(\s*,\s*\d+)?$/', $limit)) {
                $limitClause = "LIMIT {$limit}";
            } else {
                throw new Exception("Invalid LIMIT value: {$limit}");
            }
        }

        // 构建完整的 SQL 查询
        $sql = "SELECT {$fields} FROM {$table} {$where} {$orderBy} {$limitClause}";

        // 调试：打印生成的 SQL 查询
        error_log("Generated SQL: {$sql}");

        $stmt = $this->connections[$connection]->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * 插入数据（支持单条或批量）
     *
     * @param string $table 表名
     * @param array $data 单条数据（关联数组）或批量数据（二维数组）
     * @param string $connection 数据库连接名称
     * @return bool 是否插入成功
     */
    public function add($table, $data, $connection = 'default')
    {
        if (!isset($this->connections[$connection])) {
            throw new Exception("Connection '{$connection}' not found.");
        }

        $isBatch = isset($data[0]) && is_array($data[0]);

        if ($isBatch) {
            $keys = array_keys(reset($data));
            $placeholders = '(' . implode(',', array_fill(0, count($keys), '?')) . ')';
            $values = [];

            foreach ($data as $row) {
                $values = array_merge($values, array_values($row));
            }

            $sql = "INSERT INTO {$table} (" . implode(',', $keys) . ") VALUES " . implode(',', array_fill(0, count($data), $placeholders));
        } else {
            $keys = array_keys($data);
            $placeholders = '(' . implode(',', array_fill(0, count($keys), '?')) . ')';
            $values = array_values($data);

            $sql = "INSERT INTO {$table} (" . implode(',', $keys) . ") VALUES {$placeholders}";
        }

        $stmt = $this->connections[$connection]->prepare($sql);
        return $stmt->execute($values);
    }

    /**
     * 删除数据（支持单条或批量）
     *
     * @param string $table 表名
     * @param string|array $conditions 条件（字符串或数组）
     * @param string $connection 数据库连接名称
     * @return bool 是否删除成功
     */
    public function del($table, $conditions, $connection = 'default')
    {
        if (!isset($this->connections[$connection])) {
            throw new Exception("Connection '{$connection}' not found.");
        }

        $params = [];
        $where = '';

        if (is_array($conditions)) {
            $whereClauses = [];
            foreach ($conditions as $key => $value) {
                $whereClauses[] = "{$key} = ?";
                $params[] = $value;
            }
            $where = !empty($whereClauses) ? "WHERE " . implode(' AND ', $whereClauses) : '';
        } elseif (is_string($conditions) && !empty($conditions)) {
            // 直接使用字符串形式的条件（不推荐）
            $where = "WHERE {$conditions}";
        }

        $sql = "DELETE FROM {$table} {$where}";

        $stmt = $this->connections[$connection]->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * 修改数据（支持单条或批量）
     *
     * @param string $table 表名
     * @param array $data 更新的数据（关联数组）
     * @param string|array $conditions 条件（字符串或数组）
     * @param string $connection 数据库连接名称
     * @return bool 是否修改成功
     */
    public function edit($table, $data, $conditions, $connection = 'default')
    {
        if (!isset($this->connections[$connection])) {
            throw new Exception("Connection '{$connection}' not found.");
        }

        $updates = [];
        $params = array_values($data);

        foreach ($data as $key => $value) {
            $updates[] = "{$key} = ?";
        }

        $where = '';
        if (is_array($conditions)) {
            $whereClauses = [];
            foreach ($conditions as $key => $value) {
                $whereClauses[] = "{$key} = ?";
                $params[] = $value;
            }
            $where = !empty($whereClauses) ? "WHERE " . implode(' AND ', $whereClauses) : '';
        } elseif (is_string($conditions) && !empty($conditions)) {
            // 直接使用字符串形式的条件（不推荐）
            $where = "WHERE {$conditions}";
        }

        $sql = "UPDATE {$table} SET " . implode(', ', $updates) . " {$where}";

        $stmt = $this->connections[$connection]->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * 获取数据库服务器版本（带连接名前缀）
     *
     * @return string 数据库版本信息
     */
    public function getVersion()
    {
        if (empty($this->connections)) {
            return '未启用数据库';
        }

        $versionList = [];

        foreach ($this->connections as $name => $pdo) {
            $version = $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
            $versionList[] = "{$name}-{$version}";
        }

        return implode(', ', $versionList);
    }
}