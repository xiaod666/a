<?php
// class/Mine.php

class Mine
{
    private $modules = []; // 存储动态加载的模块

    public function __construct()
    {
        // 自动加载 class 目录下的所有类
        $this->autoloadClasses();
    }

    private function autoloadClasses()
    {
        // 获取 class 目录下的所有 PHP 文件
        $classDir = __DIR__;
        foreach (glob($classDir . '/*.php') as $file) {
            // 获取类名（文件名去掉 .php 后缀）
            $className = basename($file, '.php');

            // 排除当前 Mine 类
            if ($className === 'Mine') {
                continue;
            }

            // 动态加载类并将其存储到 $modules 中
            require_once $file;
            if (class_exists($className)) {
                $this->modules[$className] = new $className();
            }
        }
    }

    // 魔术方法：获取动态属性
    public function __get($name)
    {
        // 尝试匹配大小写不敏感的模块名称
        foreach ($this->modules as $key => $module) {
            if (strtolower($key) === strtolower($name)) {
                return $module;
            }
        }
        return null;
    }

    // 魔术方法：设置动态属性
    public function __set($name, $value)
    {
        $this->modules[$name] = $value;
    }
}