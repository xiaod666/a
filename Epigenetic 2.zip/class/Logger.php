<?php
// class/Logger.php

class Logger
{
    private $logFile;

    public function __construct()
    {
        // 日志文件路径
        $this->logFile = __DIR__ . '/../data/logs/' . date('Y-m-d') . '.log';
        // 确保日志目录存在
        if (!is_dir(dirname($this->logFile))) {
            mkdir(dirname($this->logFile), 0777, true);
        }
    }

    public function log($message)
    {
        // 写入日志
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message" . PHP_EOL;
        file_put_contents($this->logFile, $logMessage, FILE_APPEND);
    }

    public function error($message)
    {
        // 记录错误日志
        $this->log("[ERROR] $message");
    }

    public function info($message)
    {
        // 记录普通日志
        $this->log("[INFO] $message");
    }
}