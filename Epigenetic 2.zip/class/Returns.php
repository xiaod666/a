<?php

class Returns
{
    /**
     * 返回错误信息
     *
     * @param string $message 错误信息
     * @return void 输出 JSON 格式字符串
     */
    public function error($message)
    {
        echo json_encode([
            'state' => 'error',
            'msg'   => $message
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * 返回成功信息
     *
     * @param string $message 成功信息
     * @return void 输出 JSON 格式字符串
     */
    public function success($message)
    {
        echo json_encode([
            'state' => 'success',
            'msg'   => $message
        ], JSON_UNESCAPED_UNICODE);
    }
}