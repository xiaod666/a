<?php
// controller/template.php

class Template
{
    private $viewFile = null; // 视图文件路径
    private $data = []; // 传递给视图的数据
    private $customTags = []; // 自定义标签解析器

    public function __construct()
    {
        // 动态加载所有自定义标签解析逻辑
        $this->loadCustomTags();
    }

    private function loadCustomTags()
    {
        $tagsDir = ROOT_PATH . '/view_functions/';
        if (!is_dir($tagsDir)) {
            throw new Exception("错误: 自定义标签目录 '$tagsDir' 不存在！");
        }

        // 遍历目录，加载所有标签解析文件
        foreach (glob($tagsDir . '*.php') as $file) {
            $tagName = pathinfo($file, PATHINFO_FILENAME); // 获取文件名作为标签名
            $callback = include $file; // 加载文件并获取回调函数
            if (is_callable($callback)) {
                $this->customTags[$tagName] = $callback;
            } else {
                throw new Exception("错误: 文件 '$file' 返回的不是有效的回调函数！");
            }
        }
    }

    public function show($view)
    {
        $this->viewFile = $view;
    }

    public function give($key, $value)
    {
        $this->data[$key] = $value;
    }

    public function render($app)
    {
        if ($this->viewFile) {
            // 定义主题路径
            if (!defined('THEME_PATH')) {
                define('THEME_PATH', ROOT_PATH . "/theme/$app/");
            }

            // 获取视图文件路径
            $viewPath = THEME_PATH . ltrim($this->viewFile, '/');
            if (!file_exists($viewPath)) {
                echo "视图文件 '$viewPath' 不存在！";
                return;
            }

            global $config;

            // 缓存相关配置
            $cacheEnabled = $config['Show_cache'] ?? false;
            $cacheDir = ROOT_PATH . '/cache/' . $app . '/';
            $cacheFile = $cacheDir . ltrim($this->viewFile, '/') . '.php';

            if ($cacheEnabled) {
                // 创建缓存目录
                if (!is_dir($cacheDir)) {
                    mkdir($cacheDir, 0755, true);
                }

                // 如果缓存文件不存在或视图文件更新时间晚于缓存文件
                if (!file_exists($cacheFile) || filemtime($viewPath) > filemtime($cacheFile)) {
                    $this->generateCache($viewPath, $cacheFile);
                }

                // 加载缓存视图
                $this->loadCachedView($cacheFile);
            } else {
                // 直接渲染视图
                $this->renderView($viewPath);
            }
        }
    }

    private function generateCache($viewPath, $cacheFile)
    {
        $content = file_get_contents($viewPath);

        // 解析自定义标签
        $content = $this->parseCustomTags($content);

        // 检查安全性
        $this->checkSecurity($content);

        // 确保缓存文件所在目录存在
        $cacheDir = dirname($cacheFile);
        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true); // 递归创建目录
        }

        // 写入缓存文件
        if (file_put_contents($cacheFile, $content) === false) {
            echo "缓存文件写入失败：$cacheFile";
            return;
        }
    }

    private function loadCachedView($cacheFile)
    {
        if (!file_exists($cacheFile)) {
            echo "缓存文件 '$cacheFile' 不存在！";
            return;
        }

        extract($this->data);

        ob_start();
        include $cacheFile;
        $output = ob_get_clean();

        echo $output;
    }

    private function renderView($viewPath)
    {
        // 读取视图文件内容
        $content = file_get_contents($viewPath);

        // 解析自定义标签
        $content = $this->parseCustomTags($content);

        // 检查安全性
        $this->checkSecurity($content);

        // 提取数据变量
        extract($this->data);

        ob_start();
        try {
            // 执行动态生成的 PHP 代码
            eval('?>' . $content);
        } catch (Exception $e) {
            echo "模板渲染出错: " . $e->getMessage();
        }
        $output = ob_get_clean();

        echo $output;
    }

    private function parseCustomTags($content)
    {
        // 用于存储 {no}{/no} 标签内的原始内容
        $protectedContent = [];
        $placeholderPrefix = '__PROTECTED_CONTENT_';

        // 优先处理 {no}{/no} 标签
        $content = preg_replace_callback('/\{no\}(.*?)\{\/no\}/s', function ($matches) use (&$protectedContent, $placeholderPrefix) {
            $originalContent = $matches[1]; // 提取 {no}{/no} 标签内的内容
            $placeholder = $placeholderPrefix . count($protectedContent); // 生成唯一的占位符
            $protectedContent[$placeholder] = $originalContent; // 存储原始内容
            return $placeholder; // 返回占位符
        }, $content);

        // 处理 {$name} 标签，支持复杂变量写法（如 {$users['email']} 和 {$data.id}）
        $content = preg_replace_callback('/\{\$(.*?)\}/', function ($matches) {
            $variableExpression = trim($matches[1]); // 提取变量表达式

            // 替换点号语法为数组访问形式
            // 示例：将 {$name.id} 转换为 {$name['id']}
            $variableExpression = preg_replace_callback('/(\w+)\.(\w+)/', function ($dotMatches) {
                return "{$dotMatches[1]}['{$dotMatches[2]}']";
            }, $variableExpression);

            // 验证变量表达式的合法性（允许字母、数字、下划线、点号、方括号和单引号）
            if (!preg_match('/^[\w\.\[\]\']+$/u', $variableExpression)) {
                throw new Exception("无效的变量表达式: {$variableExpression}");
            }

            // 转换为 PHP 输出代码
            return "<?php echo \${$variableExpression}; ?>";
        }, $content);

        // 新增：处理 {CONSTANT_NAME} 常量标签
        $content = preg_replace_callback('/\{([A-Z_][A-Z0-9_]*)\}/', function ($matches) {
            $constantName = $matches[1]; // 提取常量名称
            return "<?php echo {$constantName}; ?>";
        }, $content);

        // 处理 {函数名(参数)} 标签，支持调用已定义的公共函数
        $content = preg_replace_callback('/\{([a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*)\s*\((.*?)\)\}/', function ($matches) {
            $functionName = $matches[1]; // 提取函数名
            $functionArgs = trim($matches[2]); // 提取参数部分

            // 检查函数是否已定义（假设公共函数已经加载到框架中）
            if (!function_exists($functionName)) {
                throw new Exception("未定义的函数: {$functionName}");
            }

            // 解析参数部分（支持逗号分隔的参数列表）
            $args = [];
            if (!empty($functionArgs)) {
                // 将参数字符串拆分为数组
                $argList = array_map('trim', explode(',', $functionArgs));
                foreach ($argList as $arg) {
                    // 如果参数是字符串，加上引号；否则保持原样
                    if (preg_match('/^[\'"].*[\'"]$/', $arg)) {
                        // 去掉外部引号并转义内部引号
                        $arg = trim($arg, '\'"');
                        $arg = '"' . addslashes($arg) . '"';
                    }
                    $args[] = $arg;
                }
            }

            // 转换为 PHP 调用代码
            return "<?php {$functionName}(" . implode(', ', $args) . "); ?>";
        }, $content);


        // 遍历所有自定义标签并调用对应的解析器
        foreach ($this->customTags as $tag => $callback) {
            if ($tag === 'variable') {
                continue; // 跳过变量解析器，因为它已经单独处理
            }

            // 匹配普通对称标签（如 {if ...}{/if}）
            $pairedPatternNormal = '/{' . preg_quote($tag, '/') . '\b(.*?)}(.*?){\/' . preg_quote($tag, '/') . '}/s';
            $content = preg_replace_callback($pairedPatternNormal, function ($matches) use ($callback, $tag) {
                $condition = trim($matches[1]); // 条件表达式（如 $a == 1）
                $innerContent = $matches[2] ?? ''; // 内部内容

                // 解析参数部分（仅适用于带参数的标签）
                $params = [];
                if (preg_match_all('/(\w+)="([^"]*)"/', $condition, $paramMatches, PREG_SET_ORDER)) {
                    foreach ($paramMatches as $match) {
                        $params[$match[1]] = $match[2];
                    }
                }

                // 对内部内容递归调用 parseCustomTags，支持嵌套标签
                $parsedInnerContent = $this->parseCustomTags($innerContent);

                // 调用对应的回调函数
                ob_start();
                try {
                    $result = call_user_func($callback, [
                        'condition' => $condition, // 将条件表达式传递给回调函数
                        'params' => $params,
                        'content' => $parsedInnerContent, // 传递递归解析后的内容
                        'viewFile' => $this->viewFile
                    ]);
                    return $result;
                } catch (Exception $e) {
                    echo "错误: " . $e->getMessage();
                }
                return ob_get_clean();
            }, $content);

            // 匹配特殊对称标签（如 {Ec:变量 参数="值"}内容{/Ec:变量}）
            $pairedPatternEc = '/\{Ec:(\w+)\b(.*?)\}(.*?)\{\/Ec:\1\}/s';
            $content = preg_replace_callback($pairedPatternEc, function ($matches) use ($callback) {
                $tagName = $matches[1]; // 提取标签名称（如 rs 或 rc）
                $paramsString = $matches[2]; // 提取参数部分
                $innerContent = $matches[3] ?? ''; // 提取内部内容

                // 解析参数部分
                $params = [];
                if (preg_match_all('/(\w+)="([^"]*)"/', $paramsString, $paramMatches, PREG_SET_ORDER)) {
                    foreach ($paramMatches as $match) {
                        $params[$match[1]] = $match[2];
                    }
                }

                // 动态生成变量名
                $variableName = $tagName;

                // 对内部内容递归调用 parseCustomTags，支持嵌套标签
                $parsedInnerContent = $this->parseCustomTags($innerContent);

                // 调用对应的回调函数
                ob_start();
                try {
                    $result = call_user_func($callback, [
                        'condition' => $paramsString, // 将参数部分传递给回调函数
                        'params' => $params,
                        'content' => $parsedInnerContent, // 传递递归解析后的内容
                        'viewFile' => $this->viewFile,
                        'variableName' => $variableName // 传递动态变量名
                    ]);
                    return $result;
                } catch (Exception $e) {
                    echo "错误: " . $e->getMessage();
                }
                return ob_get_clean();
            }, $content);

            // 匹配单标签（如 {include file="..."})
            $singlePattern = '/{' . preg_quote($tag, '/') . '\b(.*?)}/';
            $content = preg_replace_callback($singlePattern, function ($matches) use ($callback, $tag) {
                $paramsString = $matches[1] ?? ''; // 参数部分

                // 解析参数部分
                $params = [];
                if (preg_match_all('/(\w+)="([^"]*)"/', $paramsString, $paramMatches, PREG_SET_ORDER)) {
                    foreach ($paramMatches as $match) {
                        $params[$match[1]] = $match[2];
                    }
                }

                // 调用对应的回调函数
                ob_start();
                try {
                    $result = call_user_func($callback, [
                        'params' => $params,
                        'content' => '', // 单标签没有内部内容
                        'viewFile' => $this->viewFile
                    ]);
                    return $result;
                } catch (Exception $e) {
                    echo "错误: " . $e->getMessage();
                }
                return ob_get_clean();
            }, $content);
        }

        // 恢复 {no}{/no} 标签内的原始内容
        $content = str_replace(array_keys($protectedContent), array_values($protectedContent), $content);

        return $content;
    }

    private function checkSecurity($content)
    {
        global $config;

        // 获取安全模式配置
        $securityMode = $config['View_security'] ?? 'null';
        $safeFunctions = $config['View_safe_array'] ?? [];

        // 如果安全模式为 null，则不进行任何检查
        if ($securityMode === 'null') {
            return;
        }

        // 提取 PHP 函数调用
        preg_match_all('/\b([a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*)\s*\(/', $content, $matches);
        $functions = array_unique($matches[1]);

        // 根据安全模式检查函数
        if ($securityMode === 'forbid') {
            // 禁止模式：只允许不在 View_safe_array 中的函数
            $unsafeFunctions = array_intersect($functions, $safeFunctions);
            if (!empty($unsafeFunctions)) {
                throw new Exception("检测到已禁用函数调用: " . implode(', ', $unsafeFunctions));
            }
        } elseif ($securityMode === 'allow') {
            // 允许模式：只允许在 View_safe_array 中的函数
            $unsafeFunctions = array_diff($functions, $safeFunctions);
            if (!empty($unsafeFunctions)) {
                throw new Exception("检测到未授权函数调用: " . implode(', ', $unsafeFunctions));
            }
        }
    }
}