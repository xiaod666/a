<?php
if (!defined('APP_FUNCTION')) exit;

// 如果已经设置过开发者密钥（已登录），则跳转到 developer 页面
if (isset($_SESSION['developer_key'])) {
    header("Location: /developer");
    exit;
}

if (IS_POST) {
    // 输入过滤和基本校验
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (empty($username)) {
        $mine->Returns->error('用户名不能为空');
        return;
    }

    if (empty($password)) {
        $mine->Returns->error('密码不能为空');
        return;
    }

    // 准备发送的数据
    $postData = [
        'username' => $username,
        'password' => $password
    ];

    // 初始化cURL会话
    $ch = curl_init();

    // 设置cURL选项
    curl_setopt($ch, CURLOPT_URL, "http://epigenetic.shenghuilianmeng.cn/user/api_key");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));

    // 执行请求并获取响应
    $response = curl_exec($ch);

    // 检查是否有错误发生
    if (curl_errno($ch)) {
        echo json_encode(['state' => 'error', 'msg' => '网络请求失败，请稍后再试。'], JSON_UNESCAPED_UNICODE);
        curl_close($ch);
        return;
    }

    curl_close($ch);
    // 解析JSON响应
    $responseData = json_decode($response, true);

    // 判断是否登录成功
    if (isset($responseData['state']) && $responseData['state'] === 'success') {
        // 获取 key.php 文件路径
        $keyFile = ROOT_PATH . '/data/key.php';

        // 如果 key.php 不存在，就创建默认文件
        if (!file_exists($keyFile)) {
            $defaultContent = "<?php\nreturn [\n    'Developer_key' => '',\n];\n";
            if (file_put_contents($keyFile, $defaultContent) === false) {
                echo json_encode(['state' => 'error', 'msg' => '无法创建密钥文件，请检查权限。'], JSON_UNESCAPED_UNICODE);
                return;
            }
        }

        // 读取原始密钥配置数组
        $keyConfig = include $keyFile;

        // 确保是数组
        if (!is_array($keyConfig)) {
            $keyConfig = ['Developer_key' => ''];
        }

        // 更新 Developer_key
        $keyConfig['Developer_key'] = $responseData['msg'];

        // 构建新的密钥内容字符串
        $content = "<?php\nreturn [\n";
        foreach ($keyConfig as $key => $value) {
            // 所有值都转换为字符串处理，并用 addslashes 防止引号问题
            $content .= "    '{$key}' => '" . addslashes((string)$value) . "',\n";
        }
        $content .= "];\n";

        // 写入新密钥文件（覆盖原文件）
        if (file_put_contents($keyFile, $content) === false) {
            echo json_encode(['state' => 'error', 'msg' => '无法写入密钥文件，请检查权限。'], JSON_UNESCAPED_UNICODE);
            return;
        }
        // 设置 session
        $_SESSION['developer_key'] = $keyFile;
        // 返回成功消息
        echo json_encode(['state' => 'success', 'msg' => '登录成功，密钥已更新至密钥文件。'], JSON_UNESCAPED_UNICODE);
    } else {
        // 登录失败
        echo json_encode(['state' => 'error', 'msg' => '登录失败，请检查用户名或密码。'], JSON_UNESCAPED_UNICODE);
    }

    return;
}

$mine->Template->show('login.php');