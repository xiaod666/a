<?php
if (!defined('APP_FUNCTION')) exit;

// 清除所有与用户相关的session数据
unset($_SESSION['developer_key']);

// 删除 data/key.php 文件
$keyFilePath = ROOT_PATH . '/data/key.php';

if (file_exists($keyFilePath)) {
    // 删除文件
    if (unlink($keyFilePath)) {
        // 如果需要，可以在这里记录日志或设置一个成功标志
    } else {
        // 如果删除失败，这里可以处理错误
        error_log("无法删除 key 文件: " . $keyFilePath);
    }
} else {
    // 如果文件不存在，可能不需要做任何事情，或者记录一条消息
    error_log("Key 文件不存在: " . $keyFilePath);
}

// 重定向到登录页面或主页
header("Location: /developer"); // 修改为您实际的登录页路径
exit;