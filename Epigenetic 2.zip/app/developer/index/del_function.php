<?php
if (!defined('APP_FUNCTION')) exit;

if (IS_POST) {
    // 获取文件名参数（防止路径穿越等安全问题）
    $fileName = basename(F('file_name')); // 使用 basename 防止路径穿越攻击

    // 构造文件路径
    $filePath = ROOT_PATH . '/function/public/' . $fileName;

    // 检查文件是否存在
    if (file_exists($filePath)) {
        // 尝试删除文件
        if (unlink($filePath)) {
            $mine->Returns->success("文件删除成功");
        } else {
            $mine->Returns->error("文件删除失败");
        }
    } else {
        $mine->Returns->error("文件不存在");
    }

} else {
    $mine->Returns->error("方法错误：必须使用 POST 请求");
}