<?php
if (!defined('APP_FUNCTION')) exit;
$mine->template->give('sql', $mine->Sql->getVersion());
$mine->Template->show('./home.php');