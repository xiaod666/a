<?php



$mine->template->give('title', 'Epigenetic');
$mine->Template->show('./index.php');
