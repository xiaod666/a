<?php
if (!defined('APP_FUNCTION')) exit;

if (IS_POST) {
    $id = F('id');
    $key = $_SESSION['developer_key'] ?? '';

    if (empty($id)) {
        $mine->Returns->error('ID缺失');
        return;
    }

    if (empty($key)) {
        $mine->Returns->error('密钥缺失');
        return;
    }

    // 准备发送请求的数据
    $postData = [
        'id' => $id,
        'key' => $key
    ];

    // 使用 cURL 发送 POST 请求
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://epigenetic.shenghuilianmeng.cn/user/api_function');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); // 设置超时时间

    $response = curl_exec($ch);
    curl_close($ch);

    if ($response === false) {
        $mine->Returns->error('远程服务器无响应');
        return;
    }

    $result = json_decode($response, true);
    if (!is_array($result)) {
        $mine->Returns->error('返回数据格式错误');
        return;
    }

    if (isset($result['state']) && $result['state'] === 'error') {
        $mine->Returns->error($result['msg'] ?? '未知错误');
        return;
    }

    // ✅ 修改点：直接处理 $result，它就是文件数组
    foreach ($result as $item) {
        $fileName = $item['file_name'] ?? '';
        $fileCode = $item['file_code'] ?? '';

        if (empty($fileName) || empty($fileCode)) {
            continue; // 跳过无效项
        }

        $filePath = ROOT_PATH . '/function/public/' . $fileName;

        if (@file_put_contents($filePath, $fileCode) === false) {
            $mine->Returns->error("无法写入文件：{$fileName}");
            return;
        }
    }

    $mine->Returns->success('文件写入成功');
    return;
}

$mine->template->give('function', My_public_function());
$mine->Template->show('./function.php');
