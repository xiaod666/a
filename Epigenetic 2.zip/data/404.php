<!-- data/404.php -->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 错误</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        .container {
            margin-top: 10%;
        }
        h1 {
            color: #e74c3c;
        }
        p {
            color: #333;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>出错了！</h1>
    <p><?php echo htmlspecialchars($error_message ?? '未知错误'); ?></p>
</div>
</body>
</html>