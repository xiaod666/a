<?php
// data/sql.php

return [
    'sql' => [
        'host' => 'localhost',
        'username' => 'db1',
        'password' => '123456',
        'database' => 'db1',
        'port' => 3306,
        'charset' => 'utf8mb4',
    ],
    'sqls' => [
        'db1' => [
            'host' => 'localhost',
            'username' => 'db1',
            'password' => '123456',
            'database' => 'db1',
            'port' => 3306,
            'charset' => 'utf8mb4',
        ],
        'db2' => [
            'host' => 'localhost',
            'username' => 'db2',
            'password' => '123456',
            'database' => 'db2',
            'port' => 3306,
            'charset' => 'utf8mb4',
        ],
        //参考这个格式，您可以添加更多的数据库来处理读写等问题
    ],
];