<?php
// data/config.php

return [
    /* 基础配置项 */
    'Default_app' => 'developer', // 默认顶级应用名称
    'View_display' => true, // 是否开启视图模式 （true: 开启，false: 关闭）
    'Global_404' => true, // 是否开启全局 404 视图
    'Sql' => 'null', // 数据库模式：'sql' 表示单数据库，'sqls' 表示多数据库，null 表示不使用数据库，数据库配置文件data/sql.php
    /*开发者相关配置*/
    'Developer_mode' => true, // 开发者模式（true: 开启，false: 关闭,生产力环境请关闭该模式）
    'Debug' => true, // 是否开启调试模式（true: 显示错误信息，false: 隐藏错误信息）
    /* 路由相关配置项 */
    'Routing_suffix' => 'easy', // 路由后缀，默认为空，可以设置为 'html'
    'Routing_login' => true, // 是否登陆中间件 （true: 开启，false: 关闭）,登陆中间件配置文件 data/login.php
    /* 视图相关配置项 */
    'Show_cache' => false, // 是否缓存视图 （true: 开启，false: 关闭,会在cache目录生成缓存视图文件，可以有效提高视图的效率）
    'View_channels' => false, // 是否开启视图互通模式（true: 允许，false: 不允许）
    'View_security' => 'null', // 视图文件安全检查模式 （null: 不限制，forbid: 禁止模式[仅禁止使用指定的函数]，allow：允许模式[仅允许使用指定的函数]）
    'View_safe_array' => ['include', 'if','defined','U','rgba','media','scale','gradient','repeat','blur','translateY','translateX','perspective','addEventListener','addEventListener','function','getElementById','for','createElement','add','random','appendChild','querySelector','rotateY','rotateX',],
    // 允许的函数列表,用户可用自行决定增删


];