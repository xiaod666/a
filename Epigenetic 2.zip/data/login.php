<?php
// data/login.php

return [
    'developer' => [
        'protected' => true, // 是否需要登录保护
        'login_page' => 'developer/login', // 登录页面地址
        'auth_check_callback' => function () {
            // 1. 如果 session 中已有 developer_key，视为已登录
            if (isset($_SESSION['developer_key'])) {
                return true;
            }

            // 2. 检查是否存在 key.php 配置文件
            $keyFilePath = ROOT_PATH . '/data/key.php';
            if (!file_exists($keyFilePath)) {
                return false;
            }

            $keyConfig = include $keyFilePath;

            if (!isset($keyConfig['Developer_key'])) {
                return false;
            }

            $developerKey = $keyConfig['Developer_key'];

            // 3. 发起 POST 请求到验证接口
            $url = 'http://epigenetic.shenghuilianmeng.cn/user/api_login';
            $postData = ['Developer_key' => $developerKey];

            $options = [
                'http' => [
                    'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method'  => 'POST',
                    'content' => http_build_query($postData),
                ],
            ];

            $context  = stream_context_create($options);
            $response = @file_get_contents($url, false, $context);

            if ($response === false) {
                return false;
            }

            $result = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return false;
            }

            if (isset($result['state']) && $result['state'] === 'success') {
                $_SESSION['developer_key'] = $developerKey;
                return true;
            }

            return false;
        },
        'exclude_paths' => [
            '/developer/login', // 排除登录页面
        ],
    ],
    'admin' => [
        'protected' => false, // 是否需要登录保护
        'login_page' => 'admin/login', // 登录页面地址
        'auth_check_callback' => function () {
            // 示例：检查管理员是否已登录
            return isset($_SESSION['admin_id']);
        },
        'exclude_paths' => [
            '/admin/login','admin/user', // 排除登录页面
        ],
    ],
    'show' => [
        'protected' => false, // 不需要登录保护
    ],
];