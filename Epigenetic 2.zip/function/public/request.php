<?php

// 假设你在入口文件中已经定义了 IS_POST 常量
// 例如：
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     define('IS_POST', true);
// } else {
//     define('IS_POST', false);
// }

/**
 * F 函数：自动从 GET 或 POST 中取值
 * @param string $key 参数名
 * @param mixed $default 默认值（如果不存在返回该值）
 * @return mixed
 */
function F($key, $default = null) {
    if (defined('IS_POST') && IS_POST === true) {
        return isset($_POST[$key]) ? $_POST[$key] : $default;
    } else {
        return isset($_GET[$key]) ? $_GET[$key] : $default;
    }
}

/**
 * IP 函数：获取用户的IP地址
 * @return string 用户的IP地址
 */
function IP() {
    // 依次检查代理相关的HTTP头信息以获取真实IP，防止IP伪造
    if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        // HTTP_X_FORWARDED_FOR 可能包含多个IP地址，用逗号分隔
        // 这里只取第一个作为用户的真实IP地址
        $ip = explode(',', getenv('HTTP_X_FORWARDED_FOR'))[0];
    } elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    } else {
        // 默认情况下返回'0.0.0.0'，实际应用中可根据需要调整
        $ip = '0.0.0.0';
    }
    return $ip;
}