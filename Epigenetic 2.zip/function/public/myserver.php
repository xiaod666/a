<?php


// 获取当前 PHP 版本
function My_php() {
    echo PHP_VERSION;
}

// 获取当前运行系统：Windows / Linux / 其他
function My_system() {
    $os = strtoupper(substr(PHP_OS, 0, 3));
    if ($os === 'WIN') {
        echo 'Windows';
    } elseif ($os === 'LINUX') {
        echo 'Linux';
    } else {
        echo PHP_OS; // 其他系统返回原始值
    }
}

// 获取服务器环境信息（如 Nginx、Apache 等）
function My_server() {
    if (isset($_SERVER['SERVER_SOFTWARE'])) {
        echo $_SERVER['SERVER_SOFTWARE'];
    } else {
        echo 'Unknown Server';
    }
}

// 获取当前域名
function My_domain() {
    if (isset($_SERVER['HTTP_HOST'])) {
        echo $_SERVER['HTTP_HOST'];
    } else {
        echo 'Unknown Domain';
    }
}

// 获取 ROOT_PATH 下 '/class/' 目录中的所有 PHP 文件名并返回 JSON
function My_class() {
    // 检查 ROOT_PATH 是否定义
    if (!defined('ROOT_PATH')) {
        echo json_encode(['error' => 'ROOT_PATH is not defined']);
        return;
    }

    $dir = ROOT_PATH . '/class/';

    // 检查目录是否存在
    if (!is_dir($dir)) {
        echo json_encode(['error' => 'Directory does not exist: ' . $dir]);
        return;
    }

    $files = scandir($dir);
    $phpFiles = [];

    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
            $phpFiles[] = $file;
        }
    }

    return json_encode(['files' => $phpFiles]);
}
// 获取 ROOT_PATH 下 '/function/public/' 目录中的所有 PHP 文件名并返回 JSON
function My_public_function() {
    // 检查 ROOT_PATH 是否定义
    if (!defined('ROOT_PATH')) {
        echo json_encode(['error' => 'ROOT_PATH is not defined']);
        return;
    }

    $dir = ROOT_PATH . '/function/public/';

    // 检查目录是否存在
    if (!is_dir($dir)) {
        echo json_encode(['error' => 'Directory does not exist: ' . $dir]);
        return;
    }

    $files = scandir($dir);
    $phpFiles = [];

    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
            $phpFiles[] = $file;
        }
    }

    return json_encode(['files' => $phpFiles]);
}
// 获取 ROOT_PATH 下 '/view_functions/' 目录中的所有 PHP 文件名并返回 JSON
function My_view_functions() {
    // 检查 ROOT_PATH 是否定义
    if (!defined('ROOT_PATH')) {
        echo json_encode(['error' => 'ROOT_PATH is not defined']);
        return;
    }

    $dir = ROOT_PATH . '/view_functions/';

    // 检查目录是否存在
    if (!is_dir($dir)) {
        echo json_encode(['error' => 'Directory does not exist: ' . $dir]);
        return;
    }

    $files = scandir($dir);
    $phpFiles = [];

    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'php') {
            $phpFiles[] = $file;
        }
    }

    return json_encode(['files' => $phpFiles]);
}

?>