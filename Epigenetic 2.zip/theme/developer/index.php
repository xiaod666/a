<?php if(!defined('APP_FUNCTION')) exit; ?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8" />
    <title>Epigenetic框架-开发者模式</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body, html {
            height: 100%;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
        }
        #container {
            display: flex;
            height: 100vh;
        }
        #sidebar {
            width: 250px;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0,0,0,.1);
            padding: 20px;
        }
        #sidebar h2 {
            color: #333;
            margin-bottom: 20px;
        }
        #sidebar a {
            display: block;
            color: #666;
            text-decoration: none;
            padding: 10px;
            margin-bottom: 5px;
            transition: all .2s ease-in-out;
            border-radius: 4px;
        }
        #sidebar a:hover {
            background-color: #eaeaea;
            color: #333;
            text-decoration: none;
        }
        #content {
            flex: 1;
            border: none;
            background-color: #fff;
        }
        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
<div id="container">
    <!-- 左侧导航 -->
    <div id="sidebar">
        <h2>{$title}</h2>
        <a href="{WEB_URL}developer/index/home" target="contentFrame">开发首页</a>
        <a href="{WEB_URL}developer/index/class" target="contentFrame">公共类组件</a>
        <a href="{WEB_URL}developer/index/function" target="contentFrame">公共方法组件</a>
        <a href="{WEB_URL}developer/index/view_functions" target="contentFrame">视图标签组件</a>
    </div>

    <!-- 右侧内容 -->
    <iframe name="contentFrame" id="content" src="{WEB_URL}developer/index/home"></iframe>
</div>
</body>
</html>