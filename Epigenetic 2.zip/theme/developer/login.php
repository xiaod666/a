<?php if(!defined('APP_FUNCTION')) exit;?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录Epigenetic开发者</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: #0a0a1a;
            color: #fff;
            overflow: hidden;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* 粒子背景 */
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }

        .particle {
            position: absolute;
            background: rgba(0, 150, 255, 0.5);
            border-radius: 50%;
            filter: blur(1px);
            animation: float linear infinite;
        }

        @keyframes float {
            0% { transform: translateY(0) translateX(0); }
            50% { transform: translateY(-100px) translateX(100px); }
            100% { transform: translateY(0) translateX(0); }
        }

        /* 登录框 */
        .login-container {
            position: relative;
            z-index: 2;
            width: 400px;
            padding: 40px;
            background: rgba(10, 20, 40, 0.7);
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(0, 150, 255, 0.3);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(0, 150, 255, 0.2);
            transform-style: preserve-3d;
            transform: perspective(1000px);
            transition: all 0.5s ease;
        }

        .login-container:hover {
            box-shadow: 0 0 50px rgba(0, 150, 255, 0.5);
        }

        .login-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .login-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
            background: linear-gradient(90deg, #00d2ff, #3a7bd5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: 2px;
        }

        .login-header p {
            color: #aaa;
            font-size: 14px;
        }

        /* 输入框样式 */
        .input-group {
            position: relative;
            margin-bottom: 30px;
        }

        .input-group input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(20, 30, 50, 0.5);
            border: 1px solid rgba(0, 150, 255, 0.3);
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            outline: none;
            transition: all 0.3s;
        }

        .input-group input:focus {
            border-color: #0096ff;
            box-shadow: 0 0 10px rgba(0, 150, 255, 0.5);
        }

        .input-group label {
            position: absolute;
            top: 15px;
            left: 20px;
            color: #aaa;
            font-size: 16px;
            pointer-events: none;
            transition: all 0.3s;
        }

        .input-group input:focus + label,
        .input-group input:valid + label {
            top: -10px;
            left: 10px;
            font-size: 12px;
            background: rgba(10, 20, 40, 0.9);
            padding: 0 5px;
            color: #0096ff;
        }

        /* 按钮样式 */
        .login-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(90deg, #00d2ff, #3a7bd5);
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 150, 255, 0.3);
        }

        .login-btn:active {
            transform: translateY(-1px);
        }

        .login-btn::after {
            content: "";
            display: block;
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: -100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: all 0.5s;
        }

        .login-btn:hover::after {
            left: 100%;
        }

        /* 底部链接 */
        .login-footer {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #aaa;
        }

        .login-footer a {
            color: #0096ff;
            text-decoration: none;
            transition: all 0.3s;
        }

        .login-footer a:hover {
            text-decoration: underline;
            color: #00d2ff;
        }

        /* 科技感装饰元素 */
        .tech-decoration {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: -1;
        }

        .corner {
            position: absolute;
            width: 30px;
            height: 30px;
            border: 2px solid #0096ff;
            opacity: 0.7;
        }

        .corner-top-left {
            top: 10px;
            left: 10px;
            border-right: none;
            border-bottom: none;
        }

        .corner-top-right {
            top: 10px;
            right: 10px;
            border-left: none;
            border-bottom: none;
        }

        .corner-bottom-left {
            bottom: 10px;
            left: 10px;
            border-right: none;
            border-top: none;
        }

        .corner-bottom-right {
            bottom: 10px;
            right: 10px;
            border-left: none;
            border-top: none;
        }

        .scan-line {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 1px;
            background: linear-gradient(90deg, transparent, #0096ff, transparent);
            animation: scan 3s linear infinite;
            opacity: 0.5;
        }

        @keyframes scan {
            0% { top: 0; }
            100% { top: 100%; }
        }

        /* 动态提示框 */
        .notification {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(10, 20, 40, 0.9);
            color: #fff;
            padding: 20px 30px;
            border-radius: 5px;
            box-shadow: 0 0 20px rgba(0, 150, 255, 0.5);
            z-index: 9999;
            font-size: 16px;
            text-align: center;
            display: none;
            animation: fadeInOut 3s ease-in-out forwards;
        }

    </style>
</head>
<body>
<!-- 粒子背景 -->
<div class="particles" id="particles"></div>

<!-- 登录框 -->
<div class="login-container">
    <!-- 科技感装饰元素 -->
    <div class="tech-decoration">
        <div class="corner corner-top-left"></div>
        <div class="corner corner-top-right"></div>
        <div class="corner corner-bottom-left"></div>
        <div class="corner corner-bottom-right"></div>
        <div class="scan-line"></div>
    </div>

    <div class="login-header">
        <h1>Epigenetic 登陆</h1>
        <p>请输入您的开发者账户以访问系统</p>
    </div>

    <form id="loginForm">
        <div class="input-group">
            <input type="text" id="username" name="username" required>
            <label for="username">用户名</label>
        </div>

        <div class="input-group">
            <input type="password" id="password" name="password" required>
            <label for="password">密码</label>
        </div>

        <button type="submit" class="login-btn">登 录</button>
    </form>

    <div class="login-footer">
        <a href="#">忘记密码?</a> | <a href="{WEB_URL}user/login/reg">注册账号</a>
    </div>
</div>

<!-- 动态提示框 -->
<div id="notification" class="notification"></div>

<script>
    // 创建粒子效果
    document.addEventListener('DOMContentLoaded', function() {
        // 简单的粒子动画生成
        const particlesContainer = document.getElementById("particles");
        for (let i = 0; i < 100; i++) {
            const particle = document.createElement("div");
            particle.classList.add("particle");
            particle.style.width = particle.style.height = Math.random() * 10 + 5 + "px";
            particle.style.left = Math.random() * 100 + "%";
            particle.style.top = Math.random() * 100 + "%";
            particle.style.animationDuration = 10 + Math.random() * 10 + "s";
            particlesContainer.appendChild(particle);
        }
        const particleCount = 50;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');

            // 随机大小
            const size = Math.random() * 5 + 1;
            particle.style.width = `${size}px`;
            particle.style.height = `${size}px`;

            // 随机位置
            particle.style.left = `${Math.random() * 100}%`;
            particle.style.top = `${Math.random() * 100}%`;

            // 随机透明度
            particle.style.opacity = Math.random() * 0.5 + 0.1;

            // 随机动画时间和延迟
            const duration = Math.random() * 20 + 10;
            const delay = Math.random() * 10;
            particle.style.animationDuration = `${duration}s`;
            particle.style.animationDelay = `${delay}s`;

            particles.appendChild(particle);
        }

        // 3D倾斜效果
        const loginContainer = document.querySelector('.login-container');
        document.addEventListener('mousemove', (e) => {
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            loginContainer.style.transform = `perspective(1000px) rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });

        // 鼠标进入时恢复原状
        loginContainer.addEventListener('mouseenter', () => {
            loginContainer.style.transition = 'all 0.3s ease';
        });

        // 鼠标离开时恢复动画
        loginContainer.addEventListener('mouseleave', () => {
            loginContainer.style.transition = 'all 0.5s ease';
            loginContainer.style.transform = 'perspective(1000px) rotateY(0deg) rotateX(0deg)';
        });
    });

    // 显示动态提示信息
    function showNotification(message) {
        const notification = document.getElementById("notification");
        notification.textContent = message;
        notification.style.display = "block";

        // 自动隐藏提示框
        setTimeout(() => {
            notification.style.display = "none";
        }, 3000); // 3秒后自动隐藏
    }

    // 拦截表单提交并使用 AJAX 提交数据
    const loginForm = document.getElementById('loginForm');
    const notification = document.getElementById("notification");

    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault(); // 阻止默认提交行为

        // 获取表单数据
        const formData = new FormData(loginForm);

        try {
            // 使用 URLSearchParams 构造表单数据
            const params = new URLSearchParams();
            formData.forEach((value, key) => {
                params.append(key, value);
            });

            // 发送 AJAX 请求
            const response = await fetch(window.location.href, { // 替换为你的后端接口地址
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                body: params,
            });

            // 读取原始响应内容（无论是否为 JSON）
            const rawResponse = await response.text();

            // 尝试将类似 JSON 的字符串解析为对象
            let result;
            try {
                result = JSON.parse(rawResponse); // 尝试解析为 JSON
            } catch (parseError) {
                console.error("解析 JSON 失败：", parseError.message);
                console.error("原始响应内容：", rawResponse);
                showNotification("服务器返回了无效的数据，请联系管理员！");
                return;
            }

            // 判断 state 并显示 msg
            if (result.state === "success") {
                showNotification(result.msg || "登录成功！");
                setTimeout(() => {
                    window.location.href = ""; // 替换为目标页面路径
                }, 1000); // 1秒后跳转
            } else if (result.state === "error") {
                showNotification(result.msg || "登录失败，请重试！");
            } else {
                showNotification("未知错误，请稍后再试！");
            }
        } catch (error) {
            console.error("登录接口请求失败：", error.message); // 只打印错误消息

            // 打印原始响应内容（如果有的话）
            if (error.response) {
                error.response.text().then((rawResponse) => {
                    console.error("后端返回的原始内容：", rawResponse);
                });
            }

            showNotification("请求失败，请检查网络连接！");
        }
    });

    // 显示动态提示信息
    function showNotification(message) {
        notification.textContent = message;
        notification.style.display = "block";

        // 自动隐藏提示框
        setTimeout(() => {
            notification.style.display = "none";
        }, 3000); // 3秒后自动隐藏
    }
</script>
</body>
</html>