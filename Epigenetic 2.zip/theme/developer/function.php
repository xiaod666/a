<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>公共方法下载中心</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            margin-top: 0;
            color: #333;
        }

        /* 卡片布局 */
        .cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: calc(25% - 25px); /* 默认四列 */
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: transform 0.2s;
            position: relative; /* 添加相对定位以放置VIP标签 */
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            padding: 15px;
            border-bottom: 1px solid #ddd;
            text-align: center;
            position: relative; /* 确保VIP标签在内容之上 */
        }

        .card-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
        }

        .card-classname {
            font-size: 14px;
            color: #777;
        }

        .card-body {
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-btn {
            padding: 8px 16px;
            font-size: 14px;
            border-radius: 4px;
            cursor: pointer;
            border: none;
            transition: opacity 0.2s;
        }

        .btn-download {
            background-color: #28a745;
            color: white;
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
        }

        .card-btn:hover {
            opacity: 0.9;
        }

        @media (max-width: 1200px) {
            .card {
                width: calc(33% - 22px); /* 三列 */
            }
        }

        @media (max-width: 768px) {
            .card {
                width: calc(50% - 15px); /* 双列 */
            }
        }

        @media (max-width: 480px) {
            .card {
                width: 100%; /* 单列 */
            }
            .card-body {
                flex-direction: column;
            }
            .card-btn {
                width: 100%;
                margin: 4px 0;
            }
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            width: 80%;
            height: 80%;
            max-width: 90%;
            max-height: 80%;
            overflow: auto; /* 当内容超出容器时启用滚动 */
            position: relative;
            box-shadow: 0 5px 15px rgba(0,0,0,.5);
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .vip-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: gold;
            color: #333;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: bold;
            border-radius: 4px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
            z-index: 1;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>公共方法下载中心</h2>

    <!-- 卡片列表 -->
    <div id="cards-container" class="cards"></div>

    <!-- 模态框 -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <iframe id="modalIframe" src="" style="width:100%; height:95%; border:none;"></iframe>
        </div>
    </div>

    <script>
        const apiUrl = 'http://epigenetic.shenghuilianmeng.cn/user/api_function';
        const classJson = {$function}; // 假设这是从服务器获取的数据

        async function fetchClassComponents() {
            try {
                const response = await fetch(apiUrl);
                if (!response.ok) throw new Error('Network response was not ok');
                const data = await response.json();
                return data;
            } catch (error) {
                console.error('Fetch error:', error);
                return [];
            }
        }

        function shouldShowDeleteButton(componentName, files) {
            return files.includes(componentName);
        }

        function renderCard(component, files) {
            const card = document.createElement('div');
            card.className = 'card';

            let vipBadge = '';
            if (component.is_vip === "1") {
                vipBadge = '<div class="vip-badge">VIP</div>';
            }

            const deleteBtn = shouldShowDeleteButton(component.file_name, files.files) ? `<button class="card-btn btn-delete" onclick="deleteFile('${component.id}','${component.file_name}')">删除</button>` : '';
            const downloadBtn = !deleteBtn ? `<button class="card-btn btn-download" onclick="downloadFile('${component.id}', '${component.file_name}')">下载</button>` : '';

            card.innerHTML = `
                <div class="card-header clickable" data-id="${component.id}">
                    ${vipBadge}
                    <div class="card-title">${component.file_name}</div>
                    <div class="card-classname">${component.name}</div>
                </div>
                <div class="card-body">
                    ${downloadBtn}
                    ${deleteBtn}
                </div>
            `;
            return card;
        }

        async function loadCards() {
            const cardsContainer = document.getElementById('cards-container');
            const components = await fetchClassComponents();

            components.forEach(component => {
                const card = renderCard(component, classJson);
                cardsContainer.appendChild(card);

                // 添加点击事件监听器
                card.querySelector('.card-header').addEventListener('click', () => showModal(component));
            });
        }

        async function downloadFile(id, fileName) {
            try {
                // 使用 URLSearchParams 构造表单数据
                const params = new URLSearchParams();
                params.append('id', id);

                // 发送 AJAX 请求
                const response = await fetch(window.location.href + '/../function', { // 替换为你的后端接口地址
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: params,
                });

                // 读取原始响应内容（无论是否为 JSON）
                const rawResponse = await response.text();

                console.log('原始响应内容:', rawResponse); // 打印原始响应内容

                // 尝试将类似 JSON 的字符串解析为对象
                let result;
                try {
                    result = JSON.parse(rawResponse); // 尝试解析为 JSON
                } catch (parseError) {
                    console.error("解析 JSON 失败：", parseError.message);
                    alert('服务器返回的数据格式不正确，请联系管理员。');
                    return;
                }

                // 判断 state 并显示 msg
                if (result.state === "success") {
                    alert(fileName + ' 下载请求已成功提交，请检查您的下载目录。');
                    location.reload(); // 删除成功后刷新页面
                } else {
                    alert('下载失败：' + (result.msg || '未知错误'));
                }
            } catch (error) {
                console.error("下载接口请求失败：", error.message); // 只打印错误消息

                // 如果有网络错误或其它异常情况，通知用户
                alert("请求失败，请检查网络连接！");
            }
        }

        async function deleteFile(id, fileName) {
            if (!confirm("确定要删除该文件吗？")) return;

            try {
                const params = new URLSearchParams();
                params.append('file_name', fileName);
                const response = await fetch(window.location.href + '/../del_function', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: params
                });

                const rawResponse = await response.text();

                let result;
                try {
                    result = JSON.parse(rawResponse);
                } catch (e) {
                    console.error('非JSON响应:', rawResponse);
                    alert('服务器返回了无效数据，请联系管理员。');
                    return;
                }

                if (result.state === "success") {
                    alert('删除成功：' + fileName);
                    location.reload(); // 删除成功后刷新页面
                } else {
                    alert('删除失败：' + (result.msg || '未知错误'));
                }
            } catch (error) {
                console.error('删除请求失败:', error);
                alert('网络请求失败，请检查您的连接。');
            }
        }

        function showModal(component) {
            const modal = document.getElementById('myModal');
            const modalIframe = document.getElementById('modalIframe');

            // 设置 iframe 的 src 属性
            modalIframe.src = `http://epigenetic.shenghuilianmeng.cn/user/show_function?id=${component.id}`;

            // 显示模态框
            modal.style.display = 'flex';
        }

        document.querySelector('.close').onclick = function() {
            const modal = document.getElementById('myModal');
            const modalIframe = document.getElementById('modalIframe');

            // 清空 iframe 的 src
            modalIframe.src = '';

            // 隐藏模态框
            modal.style.display = 'none';
        };

        window.onload = loadCards;
    </script>
</div>
</body>
</html>