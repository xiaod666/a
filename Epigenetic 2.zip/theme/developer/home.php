<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>开发者首页</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            margin-top: 0;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: normal;
        }
        a {
            color: blue;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }

        /* 新增样式 */
        .news-section {
            margin-top: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
        }
        .news-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .news-item {
            padding: 10px 0;
            border-bottom: 1px solid #ddd;
        }
        .news-item:last-child {
            border-bottom: none;
        }
        .news-title {
            color: red;
            font-size: 16px;
            margin: 0;
        }
        .news-content {
            color: #666;
            margin: 5px 0 0;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>系统信息</h2>
    <table>
        <tr>
            <th>站点名称</th>
            <td>Epigenetic开源PHP框架</td>
            <th>当前版本</th>
            <td>v1.0</td>
        </tr>
    </table>

    <h2>服务器信息</h2>
    <table>
        <tr>
            <th>服务器系统</th>
            <td>{My_system()}</td>
            <th>服务器域名</th>
            <td>{My_domain()}</td>
        </tr>
        <tr>
            <th>服务器环境</th>
            <td>{My_server()}</td>
            <th>PHP 版本</th>
            <td>{My_php()}</td>
        </tr>
        <tr>
            <th>数据库版本</th>
            <td>{$sql}</td>
            <th>产品声明</th>
            <td>开源产品，可以永久免费商用</td>
        </tr>
    </table>

    <!-- 新增官方资讯部分 -->
    <div class="news-section">
        <div class="news-header">
            <span>官方资讯</span>
            <a href="#">更多&gt;&gt;</a>
        </div>
        <div class="news-item">
            <p class="news-title">开发者有点懒暂时没写...</p>
        </div>
        <div class="news-item">
            <p class="news-content">开发者有点懒暂时没写...</p>
        </div>
    </div>
</div>
</body>
</html>