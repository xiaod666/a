<?php
// index.php

// 设置时区
date_default_timezone_set('Asia/Shanghai');

// 定义 ROOT_PATH 常量（网站根目录）
define('ROOT_PATH', __DIR__);

// 定义session存储目录
$sessionDir = ROOT_PATH. '/data/session';
// 检查目录是否存在，如果不存在则尝试创建
if (!is_dir($sessionDir)) {
    // 尝试创建目录
    if (mkdir($sessionDir, 0777, true) === false) {
        // 如果创建失败，抛出错误或处理异常情况
        die('无法创建session存储目录，请检查权限');
    }
}
// 设置session保存路径为当前目录下的session文件夹
session_save_path($sessionDir);
// 启动session会话
session_start();

// 定义 WEB_ROOT（网站相对路径）
$scriptName = $_SERVER['SCRIPT_NAME']; // 例如 /project/index.php
$webRoot = rtrim(dirname($scriptName), '/'); // 例如 /project/
define('WEB_ROOT', $webRoot);

// 定义 WEB_HTTP（当前请求的协议）
$http = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
define('WEB_HTTP', $http);

// 定义 WEB_URL（系统网址）
$host = $_SERVER['HTTP_HOST']; // 例如 example.com
define('WEB_URL', str_replace('\\', '/', WEB_HTTP . '://' . $host . WEB_ROOT));



// 定义 THIS_LOCAL（当前页面的完整 URL）
$requestUri = $_SERVER['REQUEST_URI']; // 例如 /project/admin/index?param=value
define('THIS_LOCAL', WEB_HTTP . '://' . $host . $requestUri);

// 定义 IS_POST 常量，用于判断是否为 POST 请求
define('IS_POST', strtolower($_SERVER['REQUEST_METHOD']) === 'post');

// 开启或关闭错误报告
$config = include ROOT_PATH . '/data/config.php';
if ($config['Debug']) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// 自动加载类
spl_autoload_register(function ($class) {
    $file = ROOT_PATH . '/class/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// 加载公共方法注册文件
require_once ROOT_PATH . '/controller/function.php';
require_once ROOT_PATH . '/controller/login.php';
// 初始化框架核心类并声明为全局变量
global $mine;
$mine = new Mine();

// 初始化路由控制器
require_once ROOT_PATH . '/controller/routing.php';
$routing = new Routing($mine->Logger);

// 执行路由
$routing->run();