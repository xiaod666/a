<?php
// controller/login.php

class LoginMiddleware
{
    private $config;

    public function __construct()
    {
        // 加载登录配置文件
        $this->config = include ROOT_PATH . '/data/login.php';
    }

    /**
     * 检查当前路径是否需要登录保护
     *
     * @param string $appName 当前应用名称
     * @param string $requestPath 当前请求路径
     */
    public function checkAccess($appName, $requestPath)
    {
        // 初始化登录保护配置
        $loginProtection = null;

        // 尝试匹配路径级别的保护配置
        foreach ($this->config as $key => $protection) {
            // 如果键包含 `/`，表示路径级别配置
            if (strpos($key, '/') !== false && strpos($requestPath, '/' . $key) === 0) {
                $loginProtection = $protection;
                break;
            }
        }

        // 如果没有找到路径级别的保护配置，尝试使用应用级别的配置
        if (!$loginProtection) {
            $loginProtection = $this->config[$appName] ?? null;
        }

        // 如果没有找到任何保护配置，直接返回
        if (!$loginProtection || !$loginProtection['protected']) {
            return;
        }

        // 检查当前路径是否在排除列表中
        $excludePaths = $loginProtection['exclude_paths'] ?? [];
        foreach ($excludePaths as $excludePath) {
            if (strpos($requestPath, $excludePath) === 0) {
                return; // 如果匹配排除路径，则不进行登录检查
            }
        }

        // 调用登录状态验证回调
        $authCheckCallback = $loginProtection['auth_check_callback'] ?? null;
        if (!is_callable($authCheckCallback) || !$authCheckCallback()) {
            // 如果未登录，跳转到对应应用的登录页面
            $loginPage = $loginProtection['login_page'] ?? '/';
            header("Location: " . WEB_URL . $loginPage);
            exit;
        }
    }
}