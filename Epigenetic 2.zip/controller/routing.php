<?php
// controller/routing.php

class Routing
{
    private $config;
    private $logger;

    public function __construct($logger)
    {
        // 加载配置
        $this->config = include ROOT_PATH . '/data/config.php';
        $this->logger = $logger; // 注入日志类

        // 验证默认应用配置
        if (empty($this->config['Default_app'])) {
            throw new Exception("全局配置文件中未设置默认应用！");
        }
    }

    public function run()
    {
        try {
            // 获取请求路径
            $request = $_SERVER['REQUEST_URI'];
            $path = trim(parse_url($request, PHP_URL_PATH), '/');

            // 移除路由后缀
            if (!empty($this->config['Routing_suffix'])) {
                $suffix = '.' . $this->config['Routing_suffix'];
                if (substr($path, -strlen($suffix)) === $suffix) {
                    $path = substr($path, 0, -strlen($suffix));
                }
            }

            // 解析路径
            $parts = explode('/', $path);

            // 确保应用有默认值
            $app = !empty($parts[0]) ? $parts[0] : $this->config['Default_app'];

            // 检查开发者模式
            if ($app === 'developer' && !$this->config['Developer_mode']) {
                throw new Exception("开发者模式已关闭，无法访问 'developer' 应用！");
            }

            // 定义全局常量 APP_NAME
            define('APP_NAME', $app);

            // 检查应用是否存在
            $appDir = ROOT_PATH . '/app/' . APP_NAME;
            if (!is_dir($appDir)) {
                throw new Exception("应用 '" . APP_NAME . "' 不存在！");
            }

            // 动态加载方法
            $methodParts = array_slice($parts, 1); // 去掉第一级（应用）
            $controllerFile = $this->resolveControllerFile($appDir, $methodParts);

            // 定义全局常量 APP_FUNCTION 和 APP_FUNCTION_SUPERIOR
            $this->defineFunctionConstants($methodParts);

            // 注册公共方法
            registerFunctions(APP_NAME, $this->config);

            // 权限检查（根据配置决定是否启用路由保护）
            if ($this->config['Routing_login']) {
                $loginMiddleware = new LoginMiddleware();
                $loginMiddleware->checkAccess(APP_NAME, '/' . $path); // 传递完整路径
            }

            // 执行应用逻辑
            global $mine; // 使用全局变量
            require_once $controllerFile;

            // 渲染视图（如果启用了视图模式且调用了 show() 方法）
            if ($this->config['View_display']) {
                $mine->template->render(APP_NAME);
            }
        } catch (Exception $e) {
            // 记录错误日志
            $this->logger->error($e->getMessage());
            // 显示错误页面
            $this->showError($e->getMessage());
        }
    }

    private function resolveControllerFile($appDir, $methodParts)
    {
        $currentPath = $appDir;

        foreach ($methodParts as $i => $part) {
            $nextPath = $currentPath . '/' . $part;

            // 检查当前部分是否是文件
            if (file_exists($nextPath . '.php')) {
                return $nextPath . '.php';
            }

            // 检查当前部分是否是目录
            if (is_dir($nextPath)) {
                $currentPath = $nextPath;
                continue;
            }

            // 如果既不是文件也不是目录，尝试补全 index.php
            if (file_exists($nextPath . '/index.php')) {
                return $nextPath . '/index.php';
            }

            // 如果找不到文件或目录，尝试补全 index/index.php
            if (is_dir($nextPath) && file_exists($nextPath . '/index/index.php')) {
                return $nextPath . '/index/index.php';
            }

            // 如果仍然找不到文件或目录，抛出异常
            throw new Exception("方法 '" . implode('/', $methodParts) . "' 在应用 '" . APP_NAME . "' 中不存在！");
        }

        // 如果没有指定方法，默认加载 index.php 或 index/index.php
        if (file_exists($currentPath . '/index.php')) {
            return $currentPath . '/index.php';
        } elseif (file_exists($currentPath . '/index/index.php')) {
            return $currentPath . '/index/index.php';
        }

        // 如果默认文件也不存在，抛出异常
        throw new Exception("默认方法 'index' 在应用 '" . APP_NAME . "' 中不存在！");
    }

    private function defineFunctionConstants($methodParts)
    {
        // 定义 APP_FUNCTION 和 APP_FUNCTION_SUPERIOR
        $functionCount = count($methodParts);

        if ($functionCount === 0) {
            // 没有指定方法，默认为 index
            define('APP_FUNCTION', 'index');
            define('APP_FUNCTION_SUPERIOR', APP_NAME);
        } elseif ($functionCount === 1) {
            // 只有一级方法
            define('APP_FUNCTION', $methodParts[0]);
            define('APP_FUNCTION_SUPERIOR', APP_NAME);
        } else {
            // 多级方法
            define('APP_FUNCTION', $methodParts[$functionCount - 1]); // 当前方法
            define('APP_FUNCTION_SUPERIOR', $methodParts[$functionCount - 2]); // 上级方法
        }
    }

    private function showError($message)
    {
        global $config; // 获取全局配置
        if ($config['Global_404']) {
            // 使用全局 404 页面
            $error_message = $message; // 定义错误信息
            extract(['error_message' => $error_message]); // 提取变量
            include ROOT_PATH . '/data/404.php'; // 包含 404 页面
        } else {
            // 直接输出普通文字
            echo "出错了！: $message";
        }
    }
}