<?php
// controller/function.php

/**
 * 注册公共方法
 *
 * @param string $app 当前应用名称
 * @param array $config 全局配置
 */
function registerFunctions($app, $config)
{
    // 注册全局公共方法
    foreach (glob(ROOT_PATH . '/function/public/*.php') as $file) {
        require_once $file;
    }

    // 注册应用专属公共方法
    $appFunctionDir = ROOT_PATH . '/function/' . $app;
    if (is_dir($appFunctionDir)) {
        foreach (glob($appFunctionDir . '/*.php') as $file) {
            require_once $file;
        }
    }
}